
const fotos=[
	'https://picsum.photos/id/277/200/300',
	'https://picsum.photos/id/245/200/300',
	'https://picsum.photos/id/269/200/300',
	'https://picsum.photos/id/137/200/300',
	'https://picsum.photos/id/337/200/300'
];




function myfuncion() {

	let libreta='<ul>';
	for (var i = 0; i < fotos.length; i++) {
		libreta+= '<li><img src="'+fotos[i]+'"></li>';
	}

libreta+='</ul>';

	document.getElementById('galeria').innerHTML = libreta;
}


myfuncion();

/*se crea una variable libreta que es propietaria de una lista que esta lista recorrre un array de 4 
elementos 
y la operacion document es una carga de imagenes de la hoja HTML*/